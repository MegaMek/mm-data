# BattleMaster before the width change

The BattleMaster body at its full width, before it was narrowed to 90% so it reads smaller than the
hundred-ton Atlas. Height and depth were not changed. Taken from the last commit that shipped it.

| File | What it is |
|---|---|
| `body.py` | the `battlemaster(g)` function from `tools/unit_mek_chassis.py` |
| `recipe.json` | the `battlemaster` entry from `tools/unit-models/chassis.json`, expanded for readability |
| `battlemaster.g3dj` | the exported mesh |
| `battlemaster-body.json` | the exported body descriptor |
| `battlemaster-descriptor.json` | the exported mek descriptor |

## Restoring it

1. Replace the `battlemaster` entry in `tools/unit-models/chassis.json` with `recipe.json`, reformatted to
   the file's compact style. This restores the full-width sockets and mount areas and drops `widthScale`.
2. `python tools/build_modular_unit_models.py`

The body function did not change with the narrowing; `widthScale` in the recipe does the narrowing.
