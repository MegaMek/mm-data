# Atlas mk1 - preserved

The Atlas body as it stood before it was built up to carry a hundred tons, kept so it can be
restored or compared. Taken from the last commit that shipped it, not rebuilt.

617 triangles. It was the thinnest biped in the set: a torso only 10 to 14 deep, thighs 6.7 to 9
wide - lighter than the sixty-ton Rifleman's - and a front view that filled 1605 units, less than the
85-ton BattleMaster's 1852. Beside much lighter designs it read as spindly, which is why it was
replaced.

The replacement, now the default, keeps every detail of this one - the skull with its brow, glass
eyes, nose and teeth, the vents front and back, the shoulder caps, the knee blocks, the gauntlets and
knuckle plates - and adds the mass: a deeper torso, legs at the weight of the other hundred-tonners,
heavier shoulder caps, arms and fists, and the head moved forward to stay proud of the deeper chest.
Following the miniature it is squared up rather than barrel-chested: a narrower chest, shoulders close
in beside the head, legs close together, feet no wider than the shins, gorget plates framing the jaw and a
satellite dish on the head's right. It is 727 triangles and its front view fills 2000, the most of any
biped. Its sockets were re-measured to the new surfaces.

| File | What it is |
|---|---|
| `body.py` | the `atlas(g)` function from `tools/unit_mek_chassis.py` |
| `recipe.json` | the `atlas` entry from `tools/unit-models/chassis.json`, expanded for readability |
| `atlas.g3dj` | the exported mesh |
| `atlas-body.json` | the exported body descriptor |
| `atlas-descriptor.json` | the exported mek descriptor |
| `mk1-six-view.png` | bare body, six angles |

## Restoring it

1. Replace the `atlas(g)` function in `tools/unit_mek_chassis.py` with `body.py`.
2. Replace the `atlas` entry in `tools/unit-models/chassis.json` with `recipe.json`, **reformatted to
   the file's compact one-key-per-line style**. Do not paste the indented form; it will not match the
   surrounding entries. The replacement changed `sockets` and `rearSockets`, so restore both.
3. `python tools/build_modular_unit_models.py`
4. Confirm `bodies/atlas` reports 617 triangles in `manifest.json`; the replacement has 727.

The exported files here are a cross-check, not an install target: the exporter rewrites them from the
Python source, so restoring the source is what matters.
