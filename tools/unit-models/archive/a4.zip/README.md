# Locust before the rebuild

The Locust body as it shipped before it was rebuilt from the miniature, the line drawing and QA's markup.
Taken from the last commit that shipped it.

It stood 53 tall, as tall as the sixty-ton Rifleman: a small wedge pod high on long thin reverse-jointed legs,
gun pods on thin rods, two-toed feet, and glazing strips on the roof. 422 triangles.

| File | What it is |
|---|---|
| `body.py` | the `locust(g)` function from `tools/unit_mek_chassis.py` (it uses the shared `toes()` helper) |
| `recipe.json` | the `locust` entry from `tools/unit-models/chassis.json`, expanded for readability |
| `locust.g3dj` | the exported mesh |
| `locust-body.json` | the exported body descriptor |
| `locust-descriptor.json` | the exported mek descriptor |

## Restoring it

1. Replace the `locust(g)` function in `tools/unit_mek_chassis.py` with `body.py`.
2. Replace the `locust` entry in `tools/unit-models/chassis.json` with `recipe.json`, reformatted to the file's
   compact style. It has no `bodyScale`, so it comes back at its old height.
3. `python tools/build_modular_unit_models.py`
